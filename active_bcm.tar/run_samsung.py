import json
import sys
from active_bcm import ActiveBCMCalculator
from theforce.util.parallel import mpi_init 


fname_json = 'input_bcm.json'
if len(sys.argv) > 1:
    fname_json = sys.argv[1]

with open(fname_json) as f:
    json_data = json.load(f)

process_group = mpi_init ()

kernel_model = {}
for i in range (2):
    kernel_model[f'key{i+1}'] = f'0.4/model_bcm_{i+1}.pckl'
    
bcm_calc = ActiveBCMCalculator (
        covariance='pckl',
        kernel_kw=json_data['kernel_kw'],
        calculator=None,
        ediff=json_data['ediff'],
        ediff_tot = json_data['ediff_tot'],
        fdiff=json_data['fdiff'],
        process_group=process_group,
        kernel_model_dict=kernel_model, #json_data['kernel_model'],
        logfile=json_data['bcm_logfile'],
        pckl=json_data['dir_pckl'],
        pckl_id=json_data['pckl_id'],
        max_data=json_data['max_data'],
        max_inducing=json_data['max_inducing'])

bcm_calc.include_data (json_data['data'])

